<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");
  }
  require_once 'connect.php';

  $cat_id     = $_POST['cat_id'];
  $cat_name   = $_POST['cat_name'];
  $status     = $_POST['status'];
  
  $sql   =  "UPDATE category SET              
             cat_name  = '$cat_name',
             status = '$status'
             WHERE cat_id = '$cat_id'";
  $query = mysqli_query($conn,$sql);
  header('Location: categories.php');
?>