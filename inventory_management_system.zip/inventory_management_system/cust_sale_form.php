<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");
  }
  require_once 'connect.php';
  $cust_phone = $_POST['cust_phone'];
  $sql   = "SELECT * FROM customer WHERE cust_phone = '$cust_phone'";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){
        $_SESSION['cust_name'] = $row['cust_name'];
      }
?>

<form name="product_form" action="add_products.php" method="post">
  CUSTOMER NAME : 
  <input type="text" name="cust_name" value="<?php echo $_SESSION['cust_name'];?>">
  CUSTOMER PHONE : 
  <input type="text" name="cust_phone" value="<?php echo $cust_phone;?>">  
  CATEGORY : 
  <select name="prod_id">
   <option value="" selected disabled>SELECT PRODUCT</option>
    <?php
      $sql   = "SELECT * FROM product";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){
        echo '<option value='.$row['prod_id'].'>'.$row['prod_name'].'</option>';
      }
    ?>
  </select>
  <select name="quantity">
    <option value="" selected disabled>SELECT</option>     
      <?php
        for($i=1;$i<=50;$i++)
        {
           echo '<option value='.$i.'>'.$i.'</option>';
        }
      ?>
    </option>
  </select>    
  <input type="submit" name="subm" value="ADD TO CART">
</form>
<hr>

<table class="table table-striped">
<thead>
  <tr>
    <th scope="col">Product ID</th>
    <th scope="col">Product Name</th>
    <th scope="col">Product Barcode</th>
    <th scope="col">Product Description</th>
    <th scope="col">Product Price</th>
    <th scope="col">Added On </th>
    <th scope="col">Category</th>
  </tr>
</thead>

<?php
  $sql   = "SELECT * FROM product, category WHERE product.cat_id = category.cat_id";
  $result = mysqli_query($conn,$sql);
  while($row = mysqli_fetch_array($result)){
?>
<tbody>
  <tr>
    <td>
      <?php
        echo $row['prod_id'];
      ?>
    </td>
    <td>
      <?php
        echo $row['prod_name'];
      ?>
    </td>
    <td>
      <?php
        echo $row['prod_barcode'];
      ?>
    </td>
    <td>
      <?php
        echo $row['prod_desc'];
      ?>
    </td>
    <td>
      <?php
        echo $row['prod_price'];
      ?>
    </td>
    <td>
      <?php
        echo $row['date_added'];
      ?>
    </td>
    <td>
      <?php
        echo $row['cat_name'];
      ?>
    </td>

     <td>
      <a type="button" class="btn btn-danger" href="del_prod.php?prod_id=<?php echo $row['prod_id'];?>">DELETE</a>
     
    </td>

    <td>
      
        <a type="button" class="btn btn-danger" href="up_prod.php?prod_id=<?php echo $row['prod_id'];?>">UPDATE</a>
     
    </td>
    
      <?php
      }
      ?>
  </tr>

</tbody>
</table>



