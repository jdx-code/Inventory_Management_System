<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");
  }
  require_once 'connect.php';
  $cat_id = $_GET['cat_id'];
  $sql     = "DELETE FROM category where cat_id = '$cat_id'";
  $query   = mysqli_query($conn,$sql);
  header('Location: categories.php');
?>