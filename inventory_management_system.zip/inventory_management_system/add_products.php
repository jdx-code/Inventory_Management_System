<?php
  require_once 'connect.php';

  $prod_name 	= $_POST['prod_name'];
  $prod_cat 	= $_POST['prod_cat'];
  $prod_barcode = $_POST['prod_barcode'];
  $prod_price 	= $_POST['prod_price'];
  $prod_desc 	= $_POST['prod_desc'];
  $date_added 	= date('d/m/Y h:i:s', time());
  
  $sql ="INSERT INTO product (prod_id,prod_name,prod_barcode,prod_desc,prod_price,date_added,cat_id) VALUES (DEFAULT,'$prod_name','$prod_barcode','$prod_desc','$prod_price','$date_added','$prod_cat')";
  $query = mysqli_query($conn,$sql); 
  header("Location: products.php");
?>