<?php
	session_start();
	  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");      
  	}
	require_once 'connect.php';
	$_SESSION["refresh"]="no";
?>

<!DOCTYPE HTML>
<html>

<head>
  <title>INVENTORY MANAGEMENT SYSTEM</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Tangerine&amp;v1" />
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
  <script>
    function startTime() {
      var today = new Date();
      var hr = today.getHours();
      var min = today.getMinutes();
      var sec = today.getSeconds();
      ap = (hr < 12) ? "<span>AM</span>" : "<span>PM</span>";
      hr = (hr == 0) ? 12 : hr;
      hr = (hr > 12) ? hr - 12 : hr;
      //Add a zero in front of numbers<10
      hr = checkTime(hr);
      min = checkTime(min);
      sec = checkTime(sec);
      document.getElementById("clock").innerHTML = hr + ":" + min + ":" + sec + " " + ap;
      
      var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      var curWeekDay = days[today.getDay()];
      var curDay = today.getDate();
      var curMonth = months[today.getMonth()];
      var curYear = today.getFullYear();
      var date = curWeekDay+", "+curDay+" "+curMonth+" "+curYear;
      document.getElementById("date").innerHTML = date;
      
      var time = setTimeout(function(){ startTime() }, 500);
    }
    function checkTime(i) {
        if (i < 10) {
            i = "0" + i;
        }
        return i;
    }
  </script>
</head>

<body onload="startTime()">
  <div id="main">
    <div id="header">
      <div id="logo">
        <h1>INVENTORY MANAGEMENT SYSTEM<a href="#"></a></h1>
        <div class="slogan">
          <div id="clockdate" style="color:#fff; font-family: Lucida Console; font-size: 15pt;">
        <div class="clockdate-wrapper">
          <div id="clock"></div>
          <div id="date"></div>
        </div>
      </div>          
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="current" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="admin_dashboard.php">Dashboard</a></li>          
          <li><a href="categories.php"> CATEGORIES</a></li>
          <li><a href="products.php">PRODUCTS</a></li>
          <li><a href="products_quan.php">PRODUCTS QUANTITY</a></li>
          <li class="current"><a href="sales.php">SALES</a></li>
      </ul>
      </div>
    </div>
    <div id="site_content">
      <div id="sidebar_container">
        <img class="paperclip" src="style/paperclip.png" alt="paperclip" />
        <div class="sidebar">
        <!-- insert your sidebar items here -->
        <h3><?php echo "WELCOME   ".$_SESSION["username"]. "";?></h3>        
        </div>
        <!-- <img class="paperclip" src="style/paperclip.png" alt="paperclip" />
        <div class="sidebar">
          <h3>ADD NEW CATEGORY</h3>
          <form name="category_form" action="add_category.php" method="post">
            ADD NEW CATEGORY  : <input type="text" name="cat_name" value="">
            CATEGORY STATUS   : <select name="cat_status">
              <option value="" selected disabled>SELECT STATUS</option>
              <option value="active">ACTIVE</option>
              <option value="inactive">IN-ACTIVE</option>
              </select>
            <input type="submit" name="subm" value="CLICK TO ADD">
          </form>
        </div> -->
        <center><a href="logout.php"><img src="img/logout.jpg" style="width:80px;height:80px;"></a></center>              
      </div>
      <div id="content">
          Sales Form
		  <hr>
		  <form name="sales_form" action="cart.php" method="post">
		  	<table width="250" border="1" align="center" cellpadding="3" cellspacing="3">
				<tr>
					<td>
						Product
					</td>
					<td>
						<select name="pid" id="pid">
				          <option value="" selected disabled>>>>Select an Item<<<</option>     
				            <?php
				              $sql = "SELECT * FROM product, stock WHERE product.prod_id = stock.prod_id AND stock.total_quantity>=1";
				              $result = mysqli_query($conn,$sql);
				              while($row = mysqli_fetch_array($result)){
				                 echo '<option value='.$row['prod_id'].'>'.$row['prod_name'].'</option>';
				              }
				            ?>
				          </option>
				        </select> 
						<!-- <input type="" name="pid" id="pid"> -->
					</td>
				</tr>
				<tr>
					<td>
						Quantity
					</td>
					<td>
						<input type="" name="qty" id="qty">
					</td>
				</tr>
				<tr>
					<td>
						Price
					</td>
					<td>
						<input type="" name="price" id="price">
					</td>
				</tr>			
				<tr>
					<td colspan="2" align="center">
						<input type="submit" value="Add to Cart">
					</td>			
				</tr>
			</table>  	
		  </form>
      </div>
    </div>
    <div id="footer">
      <p>Copyright &copy; Pori | <a href="index.php">Inventory Management System, 2019</a></p>
    </div>
  </div>
</body>
</html>




