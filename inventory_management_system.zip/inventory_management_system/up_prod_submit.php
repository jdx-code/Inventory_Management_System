<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");
  }
  require_once 'connect.php';

  $prod_id      = $_POST['prod_id'];
  $prod_name    = $_POST['prod_name'];
  $prod_barcode = $_POST['prod_barcode'];
  $prod_desc    = $_POST['prod_desc'];
  $prod_price   = $_POST['prod_price']; 
  
  $sql =  "UPDATE product SET              
           prod_name     = '$prod_name',
           prod_barcode  = '$prod_barcode',
           prod_desc     = '$prod_desc',
           prod_price    = '$prod_price'          
           WHERE prod_id = '$prod_id'";
  $query = mysqli_query($conn,$sql);
  header('Location: products.php');
?>