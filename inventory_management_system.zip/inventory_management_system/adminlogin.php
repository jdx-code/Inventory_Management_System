<!DOCTYPE html>
<html>
<head>
	<title>ADMIN LOGIN PAGE</title>
</head>
<body>
	<form name="adminform" action="admincheck.php" method="post">
		Username : <input type="text" name="username" value="">
		Password : <input type="password" name="password" value="">
		<input type="submit" name="subBtn" value="Login">
	</form>
</body>
</html>