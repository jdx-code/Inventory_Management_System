<?php
	session_start();
	  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");      
  	}
  	require_once 'connect.php';
	$pid 		= implode(', ', $_POST['pid']);
	$prod_name 	= implode(', ', $_POST['prod_name']);
	$qty 		= implode(', ', $_POST['qty']);
	$price 		= implode(', ', $_POST['price']);
	$gtot		= $_POST['gtot'];
	$cust_ph	= $_POST['cust_ph'];
	$pay_mode 	= $_POST['pay_mode'];
	$sale_date	= date('d-m-Y') ;
	$avl_qnty	= $_POST['avl_qnty'];

	
	$sql = "INSERT INTO sales (sales_id, customer_phone, prod_name, quantity_taken, total_amount, payment_mode, date_of_sale, user_id) VALUES (DEFAULT,'$cust_ph','$prod_name','$qty','$gtot','$pay_mode','$sale_date','1')";
	mysqli_query($conn,$sql);


  	header('Location: admin_dashboard.php');
 ?>

