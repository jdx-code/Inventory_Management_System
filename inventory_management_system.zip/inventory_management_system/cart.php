<?php
	session_start();
	  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");      
  	}
 	require_once 'connect.php';
	if(isset($_SESSION["refresh"]))
	{
		if(!isset($_SESSION["cnt"]))
			$_SESSION["cnt"]=1;

		$cnt = $_SESSION["cnt"];
		$duplicate=1;
		for($i=1;$i<$cnt;$i++)
			if($_POST["pid"]==$_SESSION["pid$i"])
			{
				$duplicate=0;
				$_SESSION["qty$i"]+=$_POST["qty"];
				break;
			}
		if($duplicate==1){
			foreach($_POST as $var=>$val)
				$_SESSION["$var$cnt"] = $val;

			$_SESSION["cnt"]++;	
		}		
		unset($_SESSION["refresh"]);
	}	
?>

<!DOCTYPE HTML>
<html>

<head>
  <title>INVENTORY MANAGEMENT SYSTEM</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Tangerine&amp;v1" />
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" />
  <link rel="stylesheet" type="text/css" href="style/style.css"/>
  <script>
    function startTime() {
      var today = new Date();
      var hr = today.getHours();
      var min = today.getMinutes();
      var sec = today.getSeconds();
      ap = (hr < 12) ? "<span>AM</span>" : "<span>PM</span>";
      hr = (hr == 0) ? 12 : hr;
      hr = (hr > 12) ? hr - 12 : hr;
      //Add a zero in front of numbers<10
      hr = checkTime(hr);
      min = checkTime(min);
      sec = checkTime(sec);
      document.getElementById("clock").innerHTML = hr + ":" + min + ":" + sec + " " + ap;
      
      var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      var curWeekDay = days[today.getDay()];
      var curDay = today.getDate();
      var curMonth = months[today.getMonth()];
      var curYear = today.getFullYear();
      var date = curWeekDay+", "+curDay+" "+curMonth+" "+curYear;
      document.getElementById("date").innerHTML = date;
      
      var time = setTimeout(function(){ startTime() }, 500);
    }
    function checkTime(i) {
        if (i < 10) {
            i = "0" + i;
        }
        return i;
    }
  </script>
</head>

<body onload="startTime()">
  <div id="main">
    <div id="header">
      <div id="logo">
        <h1>INVENTORY MANAGEMENT SYSTEM<a href="#"></a></h1>
        <div class="slogan">
          <div id="clockdate" style="color:#fff; font-family: Lucida Console; font-size: 15pt;">
        <div class="clockdate-wrapper">
          <div id="clock"></div>
          <div id="date"></div>
        </div>
      </div>          
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="current" in the li tag for the selected page - to highlight which page you're on -->
          <li class="current"><a href="admin_dashboard.php">Dashboard</a></li>          
          <li><a href="categories.php"> CATEGORIES</a></li>
          <li><a href="products.php">PRODUCTS</a></li>
          <li><a href="products_quan.php">PRODUCTS QUANTITY</a></li>
          <li><a href="sales.php">SALES</a></li>
      </ul>
      </div>
    </div>
    <div id="site_content">
      <div id="sidebar_container">
        <img class="paperclip" src="style/paperclip.png" alt="paperclip" />
        <div class="sidebar">
        <!-- insert your sidebar items here -->
        <h3><?php echo "WELCOME   ".$_SESSION["username"]. "";?></h3>        
        </div>
        <img class="paperclip" src="style/paperclip.png" alt="paperclip" />
        <div class="sidebar">
          <h3>ADD NEW CATEGORY</h3>
          <form name="category_form" action="add_category.php" method="post">
            ADD NEW CATEGORY  : <input type="text" name="cat_name" value="">
            CATEGORY STATUS   : <select name="cat_status">
              <option value="" selected disabled>SELECT STATUS</option>
              <option value="active">ACTIVE</option>
              <option value="inactive">IN-ACTIVE</option>
              </select>
            <input type="submit" name="subm" value="CLICK TO ADD">
          </form>
        </div>
        <center><a href="logout.php"><img src="img/logout.jpg" style="width:80px;height:80px;"></a></center>              
      </div>
      <div id="content">
          <form id="form1" name="form1" method="post" action="billing.php">
			<table width="600" border="1" align="center" cellpadding="3" cellspacing="3">
			<tr>
				<!-- <td>
					&nbsp;
				</td> -->
				<td align="center">
					Sl. No.
				</td>			
				<td align="center">
					Product Name
				</td>
				<td align="center">
					Quantity
				</td>
				<td align="center">
					Now in Stock
				</td>
				<td align="center">
					Unit Price
				</td>			
			</tr>
			<?php
			$srno = 0;
			$gtot = 0;
			for($i=1;$i<$_SESSION["cnt"];$i++)
			{
				$srno++;
				$tot=$_SESSION["qty$i"] * $_SESSION["price$i"];
				$gtot+=$tot;
				// $sql   = "SELECT * FROM product WHERE prod_name = '".$_SESSION["pid$i"]."'";
				// $result = mysqli_query($conn,$sql);
			 //    while($row = mysqli_fetch_array($result)){
			?>
			<tr>
				<!-- <td>
					<input type="checkbox" name="check[]" id="check[]">
				</td> -->
				<td align="center"><?=$srno?></td>		
				<input type="hidden" name="pid[]" id="pid" value="<?=$_SESSION["pid$i"]?>">
				<?php
					$sql   = "SELECT * FROM product, stock WHERE product.prod_id = stock.prod_id AND product.prod_id = '".$_SESSION["pid$i"]."'";
					$result = mysqli_query($conn,$sql);
				 		while($row = mysqli_fetch_array($result)){
			 	?>
			 	<td align="center"><input type="text" name="prod_name[]" id="prod_name" value="<?=$row["prod_name"]?>"></td>
			 	
				<td align="center"><input type="text" name="qty[]" id="qty" size="3" value="<?=$_SESSION["qty$i"]?>">
				</td>
				<?php
					$avl_qnty=$row["total_quantity"] - $_SESSION["qty$i"];
					$sql = "UPDATE stock SET total_quantity = $avl_qnty WHERE prod_id = '".$_SESSION["pid$i"]."'";
					mysqli_query($conn,$sql);
				?>
				<td align="center"><input type="text" name="avl_qnty" id="qty" size="3" value="<?=$avl_qnty?>">
				</td>
			
				<?php
			 		}
			 	?>
				<td align="center"><input type="text" name="price[]" id="price" size="3" value="<?=$_SESSION["price$i"]?>"></td>
									
				</td>
			</tr>			
			<?php			
				}
			?>
			<tr>
				<!-- <td colspan="2">
					<input type="submit" name="dc" id="dc" value="Delete Checked">
				</td> -->
				<td colspan="3" align="center"><h3>Grand Total</h3></td>
				<td colspan="3" align="center">
					<h3>
					<input type="text" name="gtot" id="gtot" size="3" value="<?=$gtot;?>" readonly>
					</h3>
				</td>
				<!-- <td colspan="3" align="center"><h3><?=$gtot;?></h3></td> -->
				<!-- <td>&nbsp;</td> -->
			</tr>	
			<tr>			
				<td colspan="4" align="right">
					<h3><a href="sales.php">Continue Shopping</a></h3>
				</td>				
			</tr>	
			</table>
			<table>
				
			</table>
			<table width="600" border="1" align="center" cellpadding="3" cellspacing="3">
			<tr>
				<td colspan="2" align="center">
					Customer Phone : <input type="text" name="cust_ph" value="">
				</td>
				<td colspan="2" align="center">
					Payment Mode : 
					<select name="pay_mode">
						<option value="" selected disabled>Select Mode of Payment</option>
						<option value="cash">Cash</option>
						<option value="card">Card</option>
						<option value="credit">Credit</option>
					</select>
				</td>		
				<td colspan="3" align="center">
					<input type="submit" name="submitBtn" value="Proceed to Payment">
				</td>
			</tr>
			</table>
		</form>
      </div>
  	</div>
    </div>
    <div id="footer">
      <p>Copyright &copy; Pori | <a href="index.php">Inventory Management System, 2019</a></p>
    </div>
  </div>
</body>
</html>




