<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");
  }
  require_once 'connect.php';
?>
<!DOCTYPE HTML>
<html>

<head>
  <title>INVENTORY MANAGEMENT SYSTEM</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Tangerine&amp;v1" />
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
  <script>
    function startTime() {
      var today = new Date();
      var hr = today.getHours();
      var min = today.getMinutes();
      var sec = today.getSeconds();
      ap = (hr < 12) ? "<span>AM</span>" : "<span>PM</span>";
      hr = (hr == 0) ? 12 : hr;
      hr = (hr > 12) ? hr - 12 : hr;
      //Add a zero in front of numbers<10
      hr = checkTime(hr);
      min = checkTime(min);
      sec = checkTime(sec);
      document.getElementById("clock").innerHTML = hr + ":" + min + ":" + sec + " " + ap;
      
      var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      var curWeekDay = days[today.getDay()];
      var curDay = today.getDate();
      var curMonth = months[today.getMonth()];
      var curYear = today.getFullYear();
      var date = curWeekDay+", "+curDay+" "+curMonth+" "+curYear;
      document.getElementById("date").innerHTML = date;
      
      var time = setTimeout(function(){ startTime() }, 500);
    }
    function checkTime(i) {
        if (i < 10) {
            i = "0" + i;
        }
        return i;
    }
  </script>
</head>

<body onload="startTime()">
  <div id="main">
    <div id="header">
      <div id="logo">
        <h1>INVENTORY MANAGEMENT SYSTEM<a href="#"></a></h1>
        <div class="slogan">
          <div id="clockdate" style="color:#fff; font-family: Lucida Console; font-size: 15pt;">
        <div class="clockdate-wrapper">
          <div id="clock"></div>
          <div id="date"></div>
        </div>
      </div>          
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="current" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="admin_dashboard.php">Dashboard</a></li>          
          <li><a href="categories.php"> CATEGORIES</a></li>
          <li class="current"><a href="products.php">PRODUCTS</a></li>
          <li><a href="products_quan.php">PRODUCTS QUANTITY</a></li>
          <li><a href="sales.php">SALES</a></li>
      </ul>
      </div>
    </div>
    <div id="site_content">
      <div id="sidebar_container">
        <img class="paperclip" src="style/paperclip.png" alt="paperclip" />
        <div class="sidebar">
        <!-- insert your sidebar items here -->
        <h3><?php echo "WELCOME   ".$_SESSION["username"]. "";?></h3>        
        </div>
        <img class="paperclip" src="style/paperclip.png" alt="paperclip" />
        <div class="sidebar">
          <h3>ADD NEW PRODUCT</h3>
          <form name="product_form" action="add_products.php" method="post">
          PRODUCT NAME : 
          <input type="text" name="prod_name" value="">
          CATEGORY : 
          <select name="prod_cat">
           <option value="" selected disabled>SELECT CATEGORY</option>
            <?php
              $sql   = "SELECT * FROM category";
              $result = mysqli_query($conn,$sql);
              while($row = mysqli_fetch_array($result)){
                echo '<option value='.$row['cat_id'].'>'.$row['cat_name'].'</option>';
              }
            ?>
          </select><br>
            BARCODE : 
          <input type="text" name="prod_barcode" value=""><br>
           PRICE : <br>
          <input type="text" name="prod_price" value=""><br>
            PRODUCT DESC : 
          <input type="text" name="prod_desc" value="">
          <input type="submit" name="subm" value="CLICK TO ADD">
        </form>
        </div>
        <center><a href="logout.php"><img src="img/logout.jpg" style="width:80px;height:80px;"></a></center>              
      </div>
      <div id="content">
        <!-- insert the page content here -->
        
      <hr>

      <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">Product ID</th>
          <th scope="col">Product Name</th>
          <th scope="col">Product Barcode</th>
          <th scope="col">Product Description</th>
          <th scope="col">Product Price</th>
          <th scope="col">Added On </th>
          <th scope="col">Category</th>
          <th scope="col">Action</th>
          <th scope="col">Action</th>
        </tr>
      </thead>

      <?php
        $sql   = "SELECT * FROM product, category WHERE product.cat_id = category.cat_id";
        $result = mysqli_query($conn,$sql);
        while($row = mysqli_fetch_array($result)){
      ?>
      <tbody>
        <tr>
          <td>
            <?php
              echo $row['prod_id'];
            ?>
          </td>
          <td>
            <?php
              echo $row['prod_name'];
            ?>
          </td>
          <td>
            <?php
              echo $row['prod_barcode'];
            ?>
          </td>
          <td>
            <?php
              echo $row['prod_desc'];
            ?>
          </td>
          <td>
            <?php
              echo $row['prod_price'];
            ?>
          </td>
          <td>
            <?php
              echo $row['date_added'];
            ?>
          </td>
          <td>
            <?php
              echo $row['cat_name'];
            ?>
          </td>

           <td>
            <a type="button" class="btn btn-danger" href="del_prod.php?prod_id=<?php echo $row['prod_id'];?>">DELETE</a>
           
          </td>

          <td>
            
              <a type="button" class="btn btn-danger" href="up_prod.php?prod_id=<?php echo $row['prod_id'];?>">UPDATE</a>
           
          </td>
          
            <?php
            }
            ?>
        </tr>

      </tbody>
      </table>
      </div>
    </div>
    <div id="footer">
      <p>Copyright &copy; Pori | <a href="index.php">Inventory Management System, 2019</a></p>
    </div>
  </div>
</body>
</html>




